clear all
clc

method={'DCHWT','FPDE','GTF','FusionGAN','Structure-Aware','MWGAN'};


for i=1:39
    image_vi = im2double(imread(strcat('E:\ZhangHao\CV\work\reserch\Fusion\Mine\single\1v2_input_2v2_par_chang\second\ָ��\ָ�����\Test_vi\',num2str(i),'.bmp')));
    image_ir = im2double(imread(strcat('E:\ZhangHao\CV\work\reserch\Fusion\Mine\single\1v2_input_2v2_par_chang\second\ָ��\ָ�����\Test_ir\',num2str(i),'.bmp')));
    ir_ds_I=image_ir;
    [max(max(image_ir)),min(min(image_ir))];
%       for j=1:length(method)
%          if strcmp(method{j},'IHS')
%              F_I=T1;
%          else
        if (i-1)<=9
          F_I=im2double(imread(strcat('E:\ZhangHao\CV\work\reserch\Fusion\Mine\single\1v2_input_2v2_par_chang\second\ָ��\ָ�����\�㷨���\LPP_Result','\','F9_0',num2str(i-1),'.bmp')));
        else 
          F_I=im2double(imread(strcat('E:\ZhangHao\CV\work\reserch\Fusion\Mine\single\1v2_input_2v2_par_chang\second\ָ��\ָ�����\�㷨���\LPP_Result','\','F9_',num2str(i-1),'.bmp')));
        end           
%          end
        F_ds_I=F_I;
        fprintf('F\n')      
        [max(max(F_I)),min(min(F_I))];
        I=i;
        [VIF(8,I)]=my_evaluation(image_vi,image_ir,ir_ds_I,F_I,F_ds_I,method{6});
        disp(strcat('last',num2str(39-i)))
%         ,VIF(8,I)
%        mutural_informationre(2,I)=mutural_information(T1,pet_I,F_I,256);
%      end
end