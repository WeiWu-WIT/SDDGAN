%LC������ÿ�����ص�������ֵ�����ͼ�����������������ص�ŷʽ������ܺ͡�
file_path1 ='D:\ZhuoMian\research\NEW_PAPER\dataset\IR\';% ͼ���ļ���·��
file_path2 ='D:\ZhuoMian\research\NEW_PAPER\dataset\IR_label\';
file_path3 ='D:\ZhuoMian\research\NEW_PAPER\dataset\VI\';
file_path4 ='D:\ZhuoMian\research\NEW_PAPER\dataset\VI_label\';
file_path5 ='D:\ZhuoMian\research\NEW_PAPER\dataset\IR_LC\';
file_path6 ='D:\ZhuoMian\research\NEW_PAPER\dataset\VI_LC\';
img_path_list1 = dir(strcat(file_path1,'*.png'));%��ȡ���ļ���������bmp��ʽ��ͼ��
img_path_list2 = dir(strcat(file_path2,'*.png'));
img_path_list3 = dir(strcat(file_path3,'*.png'));
img_path_list4 = dir(strcat(file_path4,'*.png'));
img_path_list5 = dir(strcat(file_path5,'*.png'));
img_path_list6 = dir(strcat(file_path6,'*.png'));
img_num = length(img_path_list1);%��ȡͼ��������?
I=cell(1,img_num);
% printf(img_num);
if img_num > 0 %������������ͼ��
    for m = 1:img_num %��һ��ȡͼ��
        image_name1 = img_path_list1(m).name;% ͼ����
        image_name2 = img_path_list2(m).name;
        image_name3 = img_path_list3(m).name;
        image_name4 = img_path_list4(m).name;
        image_name5 = img_path_list5(m).name;
        image_name6 = img_path_list6(m).name;
        
        image_IR = imread(strcat(file_path1,image_name1));
        image_VI = imread(strcat(file_path3,image_name3));
        image_IR_Label = imread(strcat(file_path2,image_name2));
        image_VI_Label = imread(strcat(file_path4,image_name4));
        LC_IR = imread(strcat(file_path5,image_name5));
        LC_VI = imread(strcat(file_path6,image_name6));
        
%         LC_IR=rgb2gray(LC_IR);
%         LC_VI=rgb2gray(LC_VI);
        LC_IR_bg = 0;
        LC_IR_he = 0;
        LC_IR_ld = 0;
        LC_IR_lp = 0;
        LC_IR_fj = 0;
        LC_IR_jz = 0;
        LC_IR_dm = 0;
        LC_IR_yun = 0;
        LC_IR_shu = 0;
        LC_IR_yw = 0;
        LC_IR_che = 0;
        LC_IR_ren = 0;
       
        LC_VI_bg = 0;
        LC_VI_he = 0;
        LC_VI_ld = 0;
        LC_VI_lp = 0;
        LC_VI_fj = 0;
        LC_VI_jz = 0;
        LC_VI_dm = 0;
        LC_VI_yun = 0;
        LC_VI_shu = 0;
        LC_VI_yw = 0;
        LC_VI_che = 0;
        LC_VI_ren = 0;
        [t,w,z]=size(image_IR);
        if z ==3
            image_IR=rgb2gray(image_IR);
        end
%         image_IR=rgb2gray(image_IR);

        IR_bg = image_IR;
        IR_he = image_IR;
        IR_ld = image_IR;
        IR_lp = image_IR;
        IR_fj = image_IR;
        IR_jz = image_IR;
        IR_dm = image_IR;
        IR_yun = image_IR;
        IR_shu = image_IR;
        IR_yw = image_IR;
        IR_che= image_IR;
        IR_ren = image_IR;
        [t,w,z]=size(image_VI);
        if z ==3
            image_VI=rgb2gray(image_VI);
        end
%         image_VI=rgb2gray(image_VI);

        VI_bg = image_VI;
        VI_he = image_VI;
        VI_ld = image_VI;
        VI_lp = image_VI;
        VI_fj = image_VI;
        VI_jz = image_VI;
        VI_dm = image_VI;
        VI_yun = image_VI;
        VI_shu = image_VI;
        VI_yw = image_VI;
        VI_che= image_VI;
        VI_ren = image_VI;
        result = double(image_IR)/255;
%         image_IR_Label=rgb2gray(image_IR_Label);
%         image_VI_Label=rgb2gray(image_VI_Label);
        [t,w]=size(image_IR);

        for a=1:t
            for b=1:w
                c = 0;
                d = 0;
                
                %                 ����
                if image_VI_Label(a,b)==0 || image_IR_Label(a,b)==0
                    VI_bg(a,b) = image_VI(a,b);
                    IR_bg(a,b) = image_IR(a,b);
                    c = double(LC_IR(a,b));
                    d = double(LC_VI(a,b));
                    LC_IR_bg = LC_IR_bg + c;
                    LC_VI_bg = LC_VI_bg + d;
                else
                    VI_bg(a,b) = 0;
                    IR_bg(a,b) = 0;         
                end
                
                %                 ��
                if image_VI_Label(a,b)==5 || image_IR_Label(a,b)==5
                    VI_he(a,b) = image_VI(a,b);
                    IR_he(a,b) = image_IR(a,b);
                    c = double(LC_IR(a,b));
                    d = double(LC_VI(a,b));
                    LC_IR_he = LC_IR_he + c;
                    LC_VI_he = LC_VI_he + d;
                else
                    VI_he(a,b) = 0;
                    IR_he(a,b) = 0;         
                end
                
                
                %                 ·��
                if image_VI_Label(a,b)==7 || image_IR_Label(a,b)==7
                    VI_ld(a,b) = image_VI(a,b);
                    IR_ld(a,b) = image_IR(a,b);
                    c = double(LC_IR(a,b));
                    d = double(LC_VI(a,b));
                    LC_IR_ld = LC_IR_ld + c;
                    LC_VI_ld = LC_VI_ld + d;
                else
                    VI_ld(a,b) = 0;
                    IR_ld(a,b) = 0;         
                end
                
                
                %                 ·��
                if image_VI_Label(a,b)==8 || image_IR_Label(a,b)==8
                    VI_lp(a,b) = image_VI(a,b);
                    IR_fj(a,b) = image_IR(a,b);
                    c = double(LC_IR(a,b));
                    d = double(LC_VI(a,b));
                    LC_IR_lp = LC_IR_lp + c;
                    LC_VI_lp = LC_VI_lp + d;
                else
                    VI_lp(a,b) = 0;
                    IR_lp(a,b) = 0;         
                end
                
%                 �ɻ�
                if image_VI_Label(a,b)==4 || image_IR_Label(a,b)==4
                    VI_fj(a,b) = image_VI(a,b);
                    IR_fj(a,b) = image_IR(a,b);
                    c = double(LC_IR(a,b));
                    d = double(LC_VI(a,b));
                    LC_IR_fj = LC_IR_fj + c;
                    LC_VI_fj = LC_VI_fj + d;
                else
                    VI_fj(a,b) = 0;
                    IR_fj(a,b) = 0;         
                end


                               
%               ����
                if image_VI_Label(a,b)==2 || image_IR_Label(a,b)==2
                    VI_jz(a,b) = image_VI(a,b);
                    IR_jz(a,b) = image_IR(a,b);
                    c = double(LC_IR(a,b));
                    d = double(LC_VI(a,b));
                    LC_IR_jz = LC_IR_jz + c;
                    LC_VI_jz = LC_VI_jz + d;
                    
                else
                    VI_jz(a,b) = 0;
                    IR_jz(a,b) = 0;         
                end

                
%               ����
                if image_VI_Label(a,b)==12 || image_IR_Label(a,b)==12
                    VI_dm(a,b) = image_VI(a,b);
                    IR_dm(a,b) = image_IR(a,b);
                    c = double(LC_IR(a,b));
                    d = double(LC_VI(a,b));
                    LC_IR_dm = LC_IR_dm + c;
                    LC_VI_dm = LC_VI_dm + d;
%                     sprintf('%.2f ',LC_IR_dm)
                else
                    VI_dm(a,b) = 0;
                    IR_dm(a,b) = 0;         
                end

%               ��
                if image_VI_Label(a,b)==11 || image_IR_Label(a,b)==11
                    VI_yun(a,b) = image_VI(a,b);
                    IR_yun(a,b) = image_IR(a,b);
                    c = double(LC_IR(a,b));
                    d = double(LC_VI(a,b));
                    LC_IR_yun = LC_IR_yun + d;
                    LC_VI_yun = LC_VI_yun + c;
                else
                    VI_yun(a,b) = 0;
                    IR_yun(a,b) = 0;         
                end


%               ��
                if image_VI_Label(a,b)==6 || image_IR_Label(a,b)==6
                    VI_shu(a,b) = image_VI(a,b);
                    IR_shu(a,b) = image_IR(a,b);
                    c = double(LC_IR(a,b));
                    d = double(LC_VI(a,b));
                    LC_IR_shu = LC_IR_shu + d;
                    LC_VI_shu = LC_VI_shu + c;
                else
                    VI_shu(a,b) = 0;
                    IR_shu(a,b) = 0;         
                end


%               ����
                if image_VI_Label(a,b)==9 || image_IR_Label(a,b)==9
                    VI_yw(a,b) = image_VI(a,b);
                    IR_yw(a,b) = image_IR(a,b);
                    c = double(LC_IR(a,b));
                    d = double(LC_VI(a,b));
                    LC_IR_yw = LC_IR_yw + c;
                    LC_VI_yw = LC_VI_yw + d;
                else
                    VI_yw(a,b) = 0;
                    IR_yw(a,b) = 0;         
                end


%               ��
                if image_VI_Label(a,b)==3 || image_IR_Label(a,b)==3
                    VI_che(a,b) = image_VI(a,b);
                    IR_che(a,b) = image_IR(a,b);
                    c = double(LC_IR(a,b));
                    d = double(LC_VI(a,b));
                    LC_IR_che = LC_IR_che + c;
                    LC_VI_che = LC_VI_che + d;
                else
                    VI_che(a,b) = 0;
                    IR_che(a,b) = 0;         
                end


%               ��
                if image_VI_Label(a,b)==1 || image_IR_Label(a,b)==1
                    VI_ren(a,b) = image_VI(a,b);
                    IR_ren(a,b) = image_IR(a,b);
                    c = double(LC_IR(a,b));
                    d = double(LC_VI(a,b));
                    LC_IR_ren = LC_IR_ren + c;
                    LC_VI_ren = LC_VI_ren + d;
                else
                    VI_ren(a,b) = 0;
                    IR_ren(a,b) = 0;         
                end

         
                    
                
            end
        end
        
        mask = image_VI_Label;
        
        
        LC_IR_bg_ = LC_IR_bg/(LC_IR_bg + LC_VI_bg);
        LC_VI_bg_ = LC_VI_bg/(LC_IR_bg + LC_VI_bg);
        LC_IR_he_ = LC_IR_he/(LC_IR_he + LC_VI_he);
        LC_VI_he_ = LC_VI_he/(LC_IR_he + LC_VI_he);
        LC_IR_ld_ = LC_IR_ld/(LC_IR_ld + LC_VI_ld);
        LC_VI_ld_ = LC_VI_ld/(LC_IR_ld + LC_VI_ld);
        LC_IR_lp_ = LC_IR_lp/(LC_IR_lp + LC_VI_lp);
        LC_VI_lp_ = LC_VI_lp/(LC_IR_lp + LC_VI_lp);
        
        LC_IR_fj_ = LC_IR_fj/(LC_IR_fj + LC_VI_fj);
        LC_VI_fj_ = LC_VI_fj/(LC_IR_fj + LC_VI_fj);
        LC_IR_jz_ = LC_IR_jz/(LC_IR_jz + LC_VI_jz);
        LC_VI_jz_ = LC_VI_jz/(LC_IR_jz + LC_VI_jz);
        LC_IR_dm_ = LC_IR_dm/(LC_IR_dm + LC_VI_dm);
        LC_VI_dm_ = LC_VI_dm/(LC_IR_dm + LC_VI_dm);
        LC_IR_yun_ = LC_IR_yun/(LC_IR_yun + LC_VI_yun);
        LC_VI_yun_ = LC_VI_yun/(LC_IR_yun + LC_VI_yun);
        LC_IR_shu_ = LC_IR_shu/(LC_IR_shu + LC_VI_shu);
        LC_VI_shu_ = LC_VI_shu/(LC_IR_shu + LC_VI_shu);
        LC_IR_yw_ = LC_IR_yw/(LC_IR_yw + LC_VI_yw);
        LC_VI_yw_ = LC_VI_yw/(LC_IR_yw + LC_VI_yw);
        LC_IR_che_ = LC_IR_che/(LC_IR_che + LC_VI_che);
        LC_VI_che_ = LC_VI_che/(LC_IR_che + LC_VI_che);
        LC_IR_ren_ = LC_IR_ren/(LC_IR_ren + LC_VI_ren);
        LC_VI_ren_ = LC_VI_ren/(LC_IR_ren + LC_VI_ren);
 
        EnIR_bg = entrCompute(IR_bg,1);
        EnVI_bg = entrCompute(VI_bg,1); 
        EnIR_he = entrCompute(IR_he,1);
        EnVI_he = entrCompute(VI_he,1); 
        EnIR_ld = entrCompute(IR_ld,1);
        EnVI_ld = entrCompute(VI_ld,1); 
        EnIR_lp = entrCompute(IR_lp,1);
        EnVI_lp = entrCompute(VI_lp,1); 
        
        EnIR_fj = entrCompute(IR_fj,1);
        EnVI_fj = entrCompute(VI_fj,1);        
        EnIR_jz = entrCompute(IR_jz,1);
        EnVI_jz = entrCompute(VI_jz,1);
        EnIR_dm = entrCompute(IR_dm,1);
        EnVI_dm = entrCompute(VI_dm,1);       
        EnIR_yun = entrCompute(IR_yun,1);
        EnVI_yun = entrCompute(VI_yun,1);  
        EnIR_shu = entrCompute(IR_shu,1);
        EnVI_shu = entrCompute(VI_shu,1);
        EnIR_yw = entrCompute(IR_yw,1);
        EnVI_yw = entrCompute(VI_yw,1);
        EnIR_che = entrCompute(IR_che,1);
        EnVI_che = entrCompute(VI_che,1);
        EnIR_ren = entrCompute(IR_ren,1);
        EnVI_ren = entrCompute(VI_ren,1); 
        
        
        NR_IQA_IR_bg = jpeg_quality_score_(IR_bg);
        NR_IQA_VI_bg = jpeg_quality_score_(VI_bg); 
        NR_IQA_IR_he = jpeg_quality_score_(IR_he);
        NR_IQA_VI_he = jpeg_quality_score_(VI_he); 
        NR_IQA_IR_ld = jpeg_quality_score_(IR_ld);
        NR_IQA_VI_ld = jpeg_quality_score_(VI_ld); 
        NR_IQA_IR_lp = jpeg_quality_score_(IR_lp);
        NR_IQA_VI_lp = jpeg_quality_score_(VI_lp); 
        
        NR_IQA_IR_fj = jpeg_quality_score_(IR_fj);
        NR_IQA_VI_fj = jpeg_quality_score_(VI_fj);       
        NR_IQA_IR_jz = jpeg_quality_score_(IR_jz);
        NR_IQA_VI_jz = jpeg_quality_score_(VI_jz);
        NR_IQA_IR_dm = jpeg_quality_score_(IR_dm);
        NR_IQA_VI_dm = jpeg_quality_score_(VI_dm);     
        NR_IQA_IR_yun = jpeg_quality_score_(IR_yun);
        NR_IQA_VI_yun = jpeg_quality_score_(VI_yun); 
        NR_IQA_IR_shu = jpeg_quality_score_(IR_shu);
        NR_IQA_VI_shu = jpeg_quality_score_(VI_shu);
        NR_IQA_IR_yw = jpeg_quality_score_(IR_yw);
        NR_IQA_VI_yw = jpeg_quality_score_(VI_yw);
        NR_IQA_IR_che = jpeg_quality_score_(IR_che);
        NR_IQA_VI_che = jpeg_quality_score_(VI_che);
        NR_IQA_IR_ren = jpeg_quality_score_(IR_ren);
        NR_IQA_VI_ren = jpeg_quality_score_(VI_ren);
        
        
%         sco_IR_bg = LC_IR_bg_*(15*EnIR_bg + NR_IQA_IR_bg);
%         sco_VI_bg = LC_VI_bg_*(15*EnVI_bg + NR_IQA_VI_bg);
%         sco_IR_he = LC_IR_he_*(15*EnIR_he + NR_IQA_IR_he);
%         sco_VI_he = LC_VI_he_*(15*EnVI_he + NR_IQA_VI_he);
%         sco_IR_ld = LC_IR_ld_*(15*EnIR_ld + NR_IQA_IR_ld);
%         sco_VI_ld = LC_VI_ld_*(15*EnVI_ld + NR_IQA_VI_ld);
%         sco_IR_lp = LC_IR_lp_*(15*EnIR_lp + NR_IQA_IR_lp);
%         sco_VI_lp = LC_VI_lp_*(15*EnVI_lp + NR_IQA_VI_lp);
%         
%         sco_IR_fj = LC_IR_fj_*(15*EnIR_fj + NR_IQA_IR_fj);
%         sco_VI_fj = LC_VI_fj_*(15*EnVI_fj + NR_IQA_VI_fj);      
%         sco_IR_jz = LC_IR_jz_*(15*EnIR_jz + NR_IQA_IR_jz);
%         sco_VI_jz = LC_VI_jz_*(15*EnVI_jz + NR_IQA_VI_jz);
%         sco_IR_dm = LC_IR_dm_*(15*EnIR_dm + NR_IQA_IR_dm);
%         sco_VI_dm = LC_VI_dm_*(15*EnVI_dm + NR_IQA_VI_dm);    
%         sco_IR_yun = LC_IR_yun_*(15*EnIR_yun + NR_IQA_IR_yun);
%         sco_VI_yun = LC_VI_yun_*(15*EnVI_yun + NR_IQA_VI_yun); 
%         sco_IR_shu = LC_IR_shu_*(15*EnIR_shu + NR_IQA_IR_shu);
%         sco_VI_shu = LC_VI_shu_*(15*EnVI_shu + NR_IQA_VI_shu);
%         sco_IR_yw = LC_IR_yw_*(15*EnIR_yw + NR_IQA_IR_yw);
%         sco_VI_yw = LC_VI_yw_*(15*EnVI_yw + NR_IQA_VI_yw);
%         sco_IR_che = LC_IR_che_*(15*EnIR_che + NR_IQA_IR_che);
%         sco_VI_che = LC_VI_che_*(15*EnVI_che + NR_IQA_VI_che);
%         sco_IR_ren = LC_IR_ren_*(15*EnIR_ren + NR_IQA_IR_ren);
%         sco_VI_ren = LC_VI_ren_*(15*EnVI_ren + NR_IQA_VI_ren); 


        sco_IR_bg = NR_IQA_IR_bg;
        sco_VI_bg = NR_IQA_VI_bg;
        sco_IR_he = NR_IQA_IR_he;
        sco_VI_he = NR_IQA_VI_he;
        sco_IR_ld = NR_IQA_IR_ld;
        sco_VI_ld = NR_IQA_VI_ld;
        sco_IR_lp = NR_IQA_IR_lp;
        sco_VI_lp = NR_IQA_VI_lp;
        
        sco_IR_fj = NR_IQA_IR_fj;
        sco_VI_fj = NR_IQA_VI_fj;      
        sco_IR_jz = NR_IQA_IR_jz;
        sco_VI_jz = NR_IQA_VI_jz;
        sco_IR_dm = NR_IQA_IR_dm;
        sco_VI_dm = NR_IQA_VI_dm;    
        sco_IR_yun = NR_IQA_IR_yun;
        sco_VI_yun = NR_IQA_VI_yun; 
        sco_IR_shu = NR_IQA_IR_shu;
        sco_VI_shu = NR_IQA_VI_shu;
        sco_IR_yw = NR_IQA_IR_yw;
        sco_VI_yw = NR_IQA_VI_yw;
        sco_IR_che = NR_IQA_IR_che;
        sco_VI_che = NR_IQA_VI_che;
        sco_IR_ren = NR_IQA_IR_ren;
        sco_VI_ren = NR_IQA_VI_ren;  

%         sco_IR_bg = LC_IR_bg_;
%         sco_VI_bg = LC_VI_bg_;
%         sco_IR_he = LC_IR_he_;
%         sco_VI_he = LC_VI_he_;
%         sco_IR_ld = LC_IR_ld_;
%         sco_VI_ld = LC_VI_ld_;
%         sco_IR_lp = LC_IR_lp_;
%         sco_VI_lp = LC_VI_lp_;
%         
%         sco_IR_fj = LC_IR_fj_;
%         sco_VI_fj = LC_VI_fj_;      
%         sco_IR_jz = LC_IR_jz_;
%         sco_VI_jz = LC_VI_jz_;
%         sco_IR_dm = LC_IR_dm_;
%         sco_VI_dm = LC_VI_dm_;    
%         sco_IR_yun = LC_IR_yun_;
%         sco_VI_yun = LC_VI_yun_; 
%         sco_IR_shu = LC_IR_shu_;
%         sco_VI_shu = LC_VI_shu_;
%         sco_IR_yw = LC_IR_yw_;
%         sco_VI_yw = LC_VI_yw_;
%         sco_IR_che = LC_IR_che_;
%         sco_VI_che = LC_VI_che_;
%         sco_IR_ren = LC_IR_ren_;
%         sco_VI_ren = LC_VI_ren_; 
        for a=1:t
            for b=1:w
                
                %                 ����
                mask(a,b) = 255;
                result(a,b) = 0;
                
                if image_VI_Label(a,b)==0 || image_IR_Label(a,b)==0
                  
                    if sco_IR_bg/(sco_IR_bg+sco_VI_bg) >= 0.5
                        result(a,b) = double(1.6*(sco_IR_bg/(sco_IR_bg+sco_VI_bg)));
                    end  
                    if sco_IR_bg/(sco_IR_bg+sco_VI_bg) < 0.5
                        result(a,b) = double(0.2*(sco_IR_bg/(sco_IR_bg+sco_VI_bg)));
                    end
                    
                    if sco_VI_bg < sco_IR_bg
                        mask(a,b) = 127.5;
                    end
                end
                
                
                
                %                 ��
                
                if image_VI_Label(a,b)==5 || image_IR_Label(a,b)==5
                  
                    if sco_IR_he/(sco_IR_he+sco_VI_he) >= 0.5
                        result(a,b) = double(1.6*(sco_IR_he/(sco_IR_he+sco_VI_he)));
                    end  
                    if sco_IR_he/(sco_IR_he+sco_VI_he) < 0.5
                        result(a,b) = double(0.2*(sco_IR_he/(sco_IR_he+sco_VI_he)));
                    end
                    
                    if sco_VI_he < sco_IR_he
                        mask(a,b) = 127.5;
                    end
                end
                
                
                
                %                 ·��
                
                if image_VI_Label(a,b)==7 || image_IR_Label(a,b)==7
                  
                    if sco_IR_ld/(sco_IR_ld+sco_VI_ld) >= 0.5
                        result(a,b) = double(1.6*(sco_IR_ld/(sco_IR_ld+sco_VI_ld)));
                    end  
                    if sco_IR_ld/(sco_IR_ld+sco_VI_ld) < 0.5
                        result(a,b) = double(0.2*(sco_IR_ld/(sco_IR_ld+sco_VI_ld)));
                    end
                    
                    if sco_VI_ld < sco_IR_ld
                        mask(a,b) = 127.5;
                    end
                end
                
                
                
                %                 ·��

                if image_VI_Label(a,b)==8 || image_IR_Label(a,b)==8
                  
                    if sco_IR_lp/(sco_IR_lp+sco_VI_lp) >= 0.5
                        result(a,b) = double(1.6*(sco_IR_lp/(sco_IR_lp+sco_VI_lp)));
                    end  
                    if sco_IR_lp/(sco_IR_lp+sco_VI_lp) < 0.5
                        result(a,b) = double(0.2*(sco_IR_lp/(sco_IR_lp+sco_VI_lp)));
                    end
                    
                    if sco_VI_lp < sco_IR_lp
                        mask(a,b) = 127.5;
                    end
                end
                
                
%                 �ɻ�

                if image_VI_Label(a,b)==4 || image_IR_Label(a,b)==4
                    
                    if sco_IR_fj/(sco_IR_fj+sco_VI_fj) >= 0.5
                        result(a,b) = double(1.6*(sco_IR_fj/(sco_IR_fj+sco_VI_fj)));
                    end                  
                    if sco_IR_fj/(sco_IR_fj+sco_VI_fj) < 0.5
                        result(a,b) = double(0.2*(sco_IR_fj/(sco_IR_fj+sco_VI_fj)));
                    end
 
                    
                    if sco_VI_fj < sco_IR_fj
                        mask(a,b) = 127.5;
                    end
                end

                               
%               ����
              
                if image_VI_Label(a,b)==2 || image_IR_Label(a,b)==2
                    if sco_VI_jz < sco_IR_jz
                        mask(a,b) = 127.5;
                    end
                    if sco_IR_jz/(sco_IR_jz+sco_VI_jz) >= 0.5
                        result(a,b) = double(1.6*(sco_IR_jz/(sco_IR_jz+sco_VI_jz)));
                    end
                    if sco_IR_jz/(sco_IR_jz+sco_VI_jz) < 0.5
                        result(a,b) = double(0.2*(sco_IR_jz/(sco_IR_jz+sco_VI_jz)));
                    end
                end
                
%               ����
                
                if image_VI_Label(a,b)==12 || image_IR_Label(a,b)==12
                    if sco_VI_dm < sco_IR_dm
                        mask(a,b) = 127.5;
                    end
                    if sco_IR_dm/(sco_IR_dm+sco_VI_dm) >= 0.5
                        result(a,b) = double(1.6*(sco_IR_dm/(sco_IR_dm+sco_VI_dm)));
                    end
                    if sco_IR_dm/(sco_IR_dm+sco_VI_dm) < 0.5
                        result(a,b) = double(0.2*(sco_IR_dm/(sco_IR_dm+sco_VI_dm)));
                    end
                end

%               ��
               
                if image_VI_Label(a,b)==11 || image_IR_Label(a,b)==11
                    if sco_VI_yun < sco_IR_yun
                        mask(a,b) = 127.5;
                    end
                    if sco_IR_yun/(sco_IR_yun+sco_VI_yun) >= 0.5
                        result(a,b) = double(1.6*(sco_IR_yun/(sco_IR_yun+sco_VI_yun)));
                    end
                    if sco_IR_yun/(sco_IR_yun+sco_VI_yun) < 0.5
                        result(a,b) = double(0.2*(sco_IR_yun/(sco_IR_yun+sco_VI_yun)));
                    end
                end

%               ��
                
                if image_VI_Label(a,b)==6 || image_IR_Label(a,b)==6
                    if sco_VI_shu < sco_IR_shu
                        mask(a,b) = 127.5;
                    end
                    if sco_IR_shu/(sco_IR_shu+sco_VI_shu) >= 0.5
                        result(a,b) = double(1.6*(sco_IR_shu/(sco_IR_shu+sco_VI_shu)));
                    end
                    if sco_IR_shu/(sco_IR_shu+sco_VI_shu) < 0.5
                        result(a,b) = double(0.2*(sco_IR_shu/(sco_IR_shu+sco_VI_shu)));
                    end
                end

%               ����
                
                if image_VI_Label(a,b)==9 || image_IR_Label(a,b)==9
                    if sco_VI_yw < sco_IR_yw
                        mask(a,b) = 127.5;
                    end
                    if sco_IR_yw/(sco_IR_yw+sco_VI_yw) >= 0.5
                        result(a,b) = double(1.6*(sco_IR_yw/(sco_IR_yw+sco_VI_yw)));
                    end
                    if sco_IR_yw/(sco_IR_yw+sco_VI_yw) < 0.5
                        result(a,b) = double(0.2*(sco_IR_yw/(sco_IR_yw+sco_VI_yw)));
                    end
                end

%               ��
                
                if image_VI_Label(a,b)==3 || image_IR_Label(a,b)==3
                    if sco_VI_che < sco_IR_che
                        mask(a,b) = 127.5;
                    end
                    if sco_IR_che/(sco_IR_che+sco_VI_che) >= 0.5
                        result(a,b) = double(1.6*(sco_IR_che/(sco_IR_che+sco_VI_che)));
                    end
                    if sco_IR_che/(sco_IR_che+sco_VI_che) < 0.5
                        result(a,b) = double(0.2*(sco_IR_che/(sco_IR_che+sco_VI_che)));
                    end
                end

%               ��
                    
                if image_VI_Label(a,b)==1 || image_IR_Label(a,b)==1
                    if sco_VI_ren < sco_IR_ren
                        mask(a,b) = 127.5;
                    end
                    if sco_IR_ren/(sco_IR_ren+sco_VI_ren) >= 0.5
                        result(a,b) = double(1.6*(sco_IR_ren/(sco_IR_ren+sco_VI_ren)));
                    end
                    if sco_IR_ren/(sco_IR_ren+sco_VI_ren) < 0.5
                        result(a,b) = double(0.2*(sco_IR_ren/(sco_IR_ren+sco_VI_ren)));
                    end
                end
         
                    
                
            end
        end
%          result = double(result);
        
%         imwrite(result,['D:\ZhuoMian\research\NEW_PAPER\dataset\without_EN\weight\',image_name1]);
        imwrite(mask,['D:\ZhuoMian\research\NEW_PAPER\dataset\without_EN\mask_vi\',image_name1]);
%        imwrite(image_IR,['D:\ZhuoMian\dataset_new\dataset\IR_new\',num2str(m),'.bmp']);
%        imwrite(image_VI,['D:\ZhuoMian\dataset_new\dataset\VI_new\',num2str(m),'.bmp']);
%        imwrite(1-mask,['D:\ZhuoMian\dataset_new\dataset\mask_b\',num2str(m),'.bmp']);
        
    end
end 


function score = jpeg_quality_score_(img)

if (nargin > 1)
    score = -1;
    return;
end

% x1= rgb2gray(img);
x = double(img);
[M,N] = size(x);

d_h = x(:, 2:N) - x(:, 1:(N-1));

B_h = mean2(abs(d_h(:, 8:8:8*(floor(N/8)-1))));
A_h = (8*mean2(abs(d_h)) - B_h)/7;
sig_h = sign(d_h);
left_sig = sig_h(:, 1:(N-2));
right_sig = sig_h(:, 2:(N-1));
Z_h = mean2((left_sig.*right_sig)<0);


d_v = x(2:M, :) - x(1:(M-1), :);
B_v = mean2(abs(d_v(8:8:8*(floor(M/8)-1), :)));
A_v = (8*mean2(abs(d_v)) - B_v)/7;
sig_v = sign(d_v);
up_sig = sig_v(1:(M-2), :);
down_sig = sig_v(2:(M-1), :);
Z_v = mean2((up_sig.*down_sig)<0);

B = (B_h + B_v)/2;
A = (A_h + A_v)/2;
Z = (Z_h + Z_v)/2;


alpha = -245.8909;
beta = 261.9373;
gamma1 = -239.8886;
gamma2 = 160.1664;
gamma3 = 64.2859;
score = alpha + beta*(B.^(gamma1/10000))*(A.^(gamma2/10000))*(Z.^(gamma3/10000));
end